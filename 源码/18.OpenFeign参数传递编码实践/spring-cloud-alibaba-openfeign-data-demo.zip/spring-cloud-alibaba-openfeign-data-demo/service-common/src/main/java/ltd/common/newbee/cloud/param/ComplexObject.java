/**
 * 严肃声明：
 * 开源版本请务必保留此注释头信息，若删除我方将保留所有法律责任追究！
 * 本系统已申请软件著作权，受国家版权局知识产权以及国家计算机软件著作权保护！
 * 可正常分享和学习源码，不得用于违法犯罪活动，违者必究！
 * Copyright (c) 2022 程序员十三 all rights reserved.
 * 版权所有，侵权必究！
 */
package ltd.common.newbee.cloud.param;

import ltd.common.newbee.cloud.entity.NewBeeCartItem;
import ltd.common.newbee.cloud.entity.NewBeeGoodsInfo;

import java.util.List;

// 复杂类型对象 包含基础类型 简单对象
public class ComplexObject {

    private int requestNum;

    private List<Integer> cartIds;

    private List<NewBeeGoodsInfo> newBeeGoodsInfos;

    private NewBeeCartItem newBeeCartItem;

    public void setRequestNum(int requestNum) {
        this.requestNum = requestNum;
    }

    public int getRequestNum() {
        return this.requestNum;
    }

    public void setCartIds(List<Integer> cartIds) {
        this.cartIds = cartIds;
    }

    public List<Integer> getCartIds() {
        return this.cartIds;
    }

    public void setNewBeeGoodsInfos(List<NewBeeGoodsInfo> newBeeGoodsInfos) {
        this.newBeeGoodsInfos = newBeeGoodsInfos;
    }

    public List<NewBeeGoodsInfo> getNewBeeGoodsInfos() {
        return this.newBeeGoodsInfos;
    }

    public void setNewBeeCartItem(NewBeeCartItem newBeeCartItem) {
        this.newBeeCartItem = newBeeCartItem;
    }

    public NewBeeCartItem getNewBeeCartItem() {
        return this.newBeeCartItem;
    }

    @Override
    public String toString() {
        return "ComplexObject{" +
                "requestNum=" + requestNum +
                ", cartIds=" + cartIds +
                ", newBeeGoodsInfos=" + newBeeGoodsInfos +
                ", newBeeCartItem=" + newBeeCartItem +
                '}';
    }
}
