/**
 * 严肃声明：
 * 开源版本请务必保留此注释头信息，若删除我方将保留所有法律责任追究！
 * 本系统已申请软件著作权，受国家版权局知识产权以及国家计算机软件著作权保护！
 * 可正常分享和学习源码，不得用于违法犯罪活动，违者必究！
 * Copyright (c) 2022 程序员十三 all rights reserved.
 * 版权所有，侵权必究！
 */
package ltd.order.cloud.newbee.controller;

import ltd.common.newbee.cloud.entity.NewBeeCartItem;
import ltd.common.newbee.cloud.entity.NewBeeGoodsInfo;
import ltd.common.newbee.cloud.param.ComplexObject;
import ltd.common.newbee.cloud.vo.Result;
import ltd.order.cloud.newbee.openfeign.NewBeeGoodsDemoService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;

@RestController
public class NewBeeCloudTestObjectAPI {

    @Resource
    private NewBeeGoodsDemoService simpleObjectService;

    @GetMapping("/order/simpleObjectTest")
    public String simpleObjectTest1() {

        NewBeeGoodsInfo newBeeGoodsInfo = new NewBeeGoodsInfo();
        newBeeGoodsInfo.setGoodsId(2022);
        newBeeGoodsInfo.setGoodsName("Spring Cloud Alibaba 微服务架构");
        newBeeGoodsInfo.setStock(2035);

        NewBeeGoodsInfo result = simpleObjectService.updNewBeeGoodsInfo(newBeeGoodsInfo);

        return result.toString();
    }

    @GetMapping("/order/complexbjectTest")
    public String complexbjectTest() {

        ComplexObject complexObject = new ComplexObject();

        complexObject.setRequestNum(13);

        List<Integer> cartIds = new ArrayList<>();
        cartIds.add(2022);
        cartIds.add(13);
        complexObject.setCartIds(cartIds);

        NewBeeCartItem newBeeCartItem = new NewBeeCartItem();
        newBeeCartItem.setItemId(2023);
        newBeeCartItem.setCartString("newbee cloud");
        complexObject.setNewBeeCartItem(newBeeCartItem);

        List<NewBeeGoodsInfo> newBeeGoodsInfos = new ArrayList<>();
        NewBeeGoodsInfo newBeeGoodsInfo1 = new NewBeeGoodsInfo();
        newBeeGoodsInfo1.setGoodsName("Spring Cloud Alibaba 大型微服务项目实战（上册）");
        newBeeGoodsInfo1.setGoodsId(2024);
        newBeeGoodsInfo1.setStock(10000);

        NewBeeGoodsInfo newBeeGoodsInfo2 = new NewBeeGoodsInfo();
        newBeeGoodsInfo2.setGoodsName("Spring Cloud Alibaba 大型微服务项目实战（下册）");
        newBeeGoodsInfo2.setGoodsId(2025);
        newBeeGoodsInfo2.setStock(10000);
        newBeeGoodsInfos.add(newBeeGoodsInfo1);
        newBeeGoodsInfos.add(newBeeGoodsInfo2);

        complexObject.setNewBeeGoodsInfos(newBeeGoodsInfos);

        // 以上这些代码相当于平时开发时的请求参数整理

        ComplexObject result = simpleObjectService.testComplexObject(complexObject);
        return result.toString();
    }


    @GetMapping("/order/resultTest")
    public String resultTest(@RequestParam("sellStatus") int sellStatus, @RequestParam("goodsId") int goodsId) {

        Result<NewBeeGoodsInfo> goodsInfoResult = simpleObjectService.getGoodsDetail4(goodsId, sellStatus);

        return goodsInfoResult.toString();
    }


}