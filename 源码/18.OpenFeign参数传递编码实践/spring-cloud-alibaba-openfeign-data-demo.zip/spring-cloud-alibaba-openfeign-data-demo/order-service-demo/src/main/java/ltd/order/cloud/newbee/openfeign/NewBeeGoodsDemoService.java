/**
 * 严肃声明：
 * 开源版本请务必保留此注释头信息，若删除我方将保留所有法律责任追究！
 * 本系统已申请软件著作权，受国家版权局知识产权以及国家计算机软件著作权保护！
 * 可正常分享和学习源码，不得用于违法犯罪活动，违者必究！
 * Copyright (c) 2022 程序员十三 all rights reserved.
 * 版权所有，侵权必究！
 */
package ltd.order.cloud.newbee.openfeign;

import ltd.common.newbee.cloud.entity.NewBeeGoodsInfo;
import ltd.common.newbee.cloud.param.ComplexObject;
import ltd.common.newbee.cloud.vo.Result;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@FeignClient(value = "newbee-cloud-goods-service", path = "/goods")
public interface NewBeeGoodsDemoService {

    @GetMapping(value = "/{goodsId}")
    String getGoodsDetail(@PathVariable(value = "goodsId") int goodsId);

    @GetMapping(value = "/detail")
    String getGoodsDetail3(@RequestParam(value = "goodsId") int goodsId, @RequestParam(value = "sellStatus") int sellStatus);

    @GetMapping(value = "/listByIdArray")
    List<String> getGoodsArray(@RequestParam(value = "goodsIds") Integer[] goodsIds);

    @GetMapping(value = "/listByIdList")
    List<String> getGoodsList(@RequestParam(value = "goodsIds") List<Integer> goodsIds);

    @PostMapping(value = "/updNewBeeGoodsInfo")
    NewBeeGoodsInfo updNewBeeGoodsInfo(@RequestBody NewBeeGoodsInfo newBeeGoodsInfo);

    @PostMapping(value = "/testComplexObject")
    ComplexObject testComplexObject(@RequestBody ComplexObject complexObject);

    @GetMapping(value = "/testResult")
    Result<NewBeeGoodsInfo> getGoodsDetail4(@RequestParam(value = "goodsId") int goodsId, @RequestParam(value = "sellStatus") int sellStatus);
}
