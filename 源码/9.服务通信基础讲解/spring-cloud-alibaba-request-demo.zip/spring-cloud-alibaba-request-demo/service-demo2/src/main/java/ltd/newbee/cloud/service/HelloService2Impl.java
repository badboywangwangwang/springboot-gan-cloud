package ltd.newbee.cloud.service;

import org.springframework.stereotype.Component;

@Component
public class HelloService2Impl {

    public String getName(){
        return "service02";
    }
}
