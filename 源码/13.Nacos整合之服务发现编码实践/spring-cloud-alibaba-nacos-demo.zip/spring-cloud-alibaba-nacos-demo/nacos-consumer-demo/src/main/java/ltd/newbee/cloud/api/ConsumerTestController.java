/**
 * 严肃声明：
 * 开源版本请务必保留此注释头信息，若删除我方将保留所有法律责任追究！
 * 本系统已申请软件著作权，受国家版权局知识产权以及国家计算机软件著作权保护！
 * 可正常分享和学习源码，不得用于违法犯罪活动，违者必究！
 * Copyright (c) 2022 程序员十三 all rights reserved.
 * 版权所有，侵权必究！
 */
package ltd.newbee.cloud.api;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import javax.annotation.Resource;

@RestController
public class ConsumerTestController {

    @Resource
    private RestTemplate restTemplate;

    private final String SERVICE_URL = "http://newbee-cloud-goods-service";
    private final String SERVICE_URL2 = "http://newbee-cloud-goods-service2";

    // 测试方法，暂未通过Nacos调用下级服务
    @GetMapping("/nacosRegTest")
    public String nacosRegTest() {
        return "nacosRegTest";
    }

    // 通过Nacos调用下级服务
    @GetMapping("/consumerTest")
    public String consumerTest() {
        return restTemplate.getForObject(SERVICE_URL + "/goodsServiceTest", String.class);
    }

    // 通过Nacos调用下级服务
    @GetMapping("/consumerTest2")
    public String consumerTest2() {
        return restTemplate.getForObject(SERVICE_URL2 + "/goodsServiceTest", String.class);
    }
}
